package sql_util;

import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;

public class JdbcUtil {
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DBname = "test";
	private static final String URL = "jdbc:mysql://localhost:3306/"+DBname+"?useSSL=true&serverTimezone=UTC";
	private static final String USER = "root";
	private static final String PASSWORD = "root";
	public static Connection getConnection() {
		Connection con =null;
		try{
			
			Class.forName(DRIVER);

			//con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useSSL=true&serverTimezone=UTC", "root", "root");
			con = DriverManager.getConnection(URL, USER,PASSWORD);

			System.out.println("���ݿ����ӳɹ�:"+con);
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		catch(SQLException s){
			s.printStackTrace();
		} 
	return con;

	}
	
	public static void closeAll(Connection con, Statement stmt, ResultSet rs) {
		try {
			if (rs != null) {
				rs.close(); 
				rs = null;   
			}
			if (stmt != null) {
				stmt.close();
				stmt = null;
			}
			if (con != null && !con.isClosed()) {
				con.close();
				con = null;
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
		
}
